let eventos = require('events');//
let EmissorEventos = eventos.EventEmitter;

//O emissor de eventos encontra-se na propriedade EventEmitter
let ee = new EmissorEventos();
// ou criando direto sem a variavel intermediária
//let ee = new eventos.EventEmitter();
//mas da forma anterior é a melhor prática

//é registrado um ouvinte (listener) para oo evento 'dados'
//Quando esse evento acontecer a funcao passada como argumento
ee.on('dados',function(fecha){
    console.log(fecha);
});

// Emissao do evento somente uma vez
ee.emit('dados','primeira vez'+ Date.now());

setInterval(function(){
    ee.emit('dados', Date.now());
}, 500);