const prompt = require("prompt-sync")();
//parametros indicam que stamos execuando a função prompt-sync Ao Fazer
//isso a função retoma um vlaor que é uma nova função que pode ser usada para criar prompts

function saudacao(nome){
    console.log('OI '+nome + ", você perdeu");
}
function entradaNome(callback){
    let nome = prompt('Digite seu nome:');
    callback(nome); //chamando a função callback (saudação)
}

entradaNome(saudacao);
//obter o nome do usuario atraves de uma caixa de dialogo e, em seguida chamar a função de retorno
//(callback) fornecida como parametro, passando o nome ditado como argumento